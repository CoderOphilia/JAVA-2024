package OphiliaFradarick;

public class Library {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Creating Object from the Author class
		
		Author person;
		person = new Author();
		String p1 = person.author();
		String p2 = person.author_dob();
		
		//calling the method author_information()
		person.author_information(p1, p2);
		
		
		Book book;
		for(int i = 1; i<=3; i++) {
			book = new Book();
			book.book_information();
		}
		
	}
	
	

}
