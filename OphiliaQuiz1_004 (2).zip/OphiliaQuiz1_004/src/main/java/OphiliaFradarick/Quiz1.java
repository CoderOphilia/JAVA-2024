package OphiliaFradarick;

import java.util.Scanner;

public class Quiz1 {

	public static void main(String[] args) {
		
		//Getting user input
		//1. Author's name
		Scanner input = new Scanner(System.in);
		System.out.println("Enter author's name: ");
		String name = input.nextLine();
		
		//2.AUthor's DOB
		System.out.println("Enter author's year of Birth: ");
		String dob = input.nextLine();
		

		
		
		input.close();

	}

}
