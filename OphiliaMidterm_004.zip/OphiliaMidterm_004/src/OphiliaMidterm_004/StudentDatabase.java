/**
 *@author : Ophilia
 *Student ID: 300386351
 *<b>This class allows to store an array<b>
 *<b>The stored array will act as a database of any number of student objects up to 10<b>
 */
package OphiliaMidterm_004;

import java.util.Scanner;
import java.util.Arrays;

public class StudentDatabase {

	public static void main(String[] args) {
	    
		//Creating scanner for user input
		Scanner input = new Scanner(System.in);
		
		//creating an array that act as the database of any number of student objects up to 10
		Student [] students = new Student[10];
		
		//getting user input for the further evaluation
		System.out.println("Do you want to (A)add, or (C)change a record or(Q)uit>> ");
		String userInput = input.nextLine();
		
		//using switch statement to add or change the record
		switch(userInput) {
			case "A":
				addRecord(students);
				break;
			case "C":
				changeRecord(students);
				break;
			case "Q":
				System.out.println("Good bye");
				break;
			default: System.out.println("Invalid entry");
			break;
		}
		
		//terminating the scanner
		input.close();

	}
	
	/*creating a method to check whether 
	1. database is full
	2. the ID exist
	*/
	public static void addRecord(Student[] students) {
		try (Scanner input = new Scanner(System.in)) {
			if(students.length == 10) { //checking if the database is full
				System.out.println("Database is full");	
			}
			else if(students.length <10) {
				System.out.println("Enter Student name >> ");
				String studentName = input.nextLine();
				
				System.out.println("Enter Student ID >> ");
				int studentID = input.nextInt();
				
				input.nextLine();// This is to avoid the buffer
				
				//iterating through the student array object to check the student ID exists or not
				for(int i =0; i<students.length; i++) { 
					if(studentID == students[i].getStudentID()) {
						System.out.println("Sorry -- ID number already exists");
					}
				}
			}
			else {
				
				//if(students.length <10) {
					//adding student name
					System.out.println("Enter Student name >> ");
					String studentName = input.nextLine();
					students[0].setStudentName(studentName);	
					
					//adding student ID
					System.out.println("Enter Student ID >> ");
					int studentID = input.nextInt();
					students[0].setStudentID(studentID);
					
					//adding student CGPA
					System.out.println("Enter CGPA >> ");
					float studentCgpa = input.nextFloat();
					students[0].setCgpa(studentCgpa);
					
					//displaying the student information
					System.out.println("Current database:");
					System.out.println("ID #"+ students[0].getStudentID() + " "+ students[0].getStudentName()+" "+students[0].getCgpa());
					
					//addRecord(students); //Recursion
				//}
			}
		}
	}
	
	//This method is to check whether the database is empty or not
	//otherwise prompt the user to check if the requested ID 
	public static void changeRecord(Student[] arr) {
		Scanner input = new Scanner(System.in);
		if(arr.length == 0) { //checking if the array is empty/ database is empty or not
			System.out.println("Database is empty -- cannot change record");
		}
		else {
			System.out.println("Enter ID to change >> ");
			int studentID = input.nextInt();
			arr[0].setStudentID(studentID);
			
			System.out.println("Enter New CGPA>> ");
			float studentCGPA = input.nextFloat();
			arr[0].setCgpa(studentCGPA);
			System.out.println("Current database:");
			System.out.println("ID #"+ arr[0].getStudentID() + " "+ arr[0].getStudentName()+" "+arr[0].getCgpa());
			
		}
	}

}
