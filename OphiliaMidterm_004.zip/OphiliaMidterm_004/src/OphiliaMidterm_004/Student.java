/**
 * @author : Ophilia 
 * Student ID: 300386351
 * <b>This is a student class contains the field such as student id, cgpa and name<b>
 */

package OphiliaMidterm_004;

public class Student {
   //creating fields
	private int studentID;
	private float cgpa;
	private String studentName;
	
	
	//getters and setters
	//getters - allows the users to retrieve information
	//setters - allows the users to update information
	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public float getCgpa() {
		return cgpa;
	}

	public void setCgpa(float cgpa) {
		this.cgpa = cgpa;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
  
}
