package OphiliaFradarick;

import java.util.Scanner;

public class Book {
    
	String book_title;
	float price;
	String author_name;
	String author_dob;
	 
	//Constructor
	public Book(String book_title, float price, String author_name, String author_dob) {
		super();
		this.book_title = book_title;
		this.price = price;
		this.author_name = author_name;
		this.author_dob = author_dob;
	}
	
	public String bookTitle() {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter books's name: ");
		String name = input.nextLine();
		return name;
	}
	
	public String author() {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Authors's name: ");
		String name = input.nextLine();
		
		return name;
	}
	
	
	public float book_price() {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter book's price: ");
		float price = input.nextFloat();
		
		return price;
	}
	
	
	//displaying information
	public void book_information(String book_title, float price, String author_name, String author_dob) {
		System.out.println("The book's title is " + book_title);
		System.out.println("The book's price is " + price);
		System.out.println("The authors's name is " + author_name);
		System.out.println("The author's year of birth is " + author_dob);
	}
	

}
