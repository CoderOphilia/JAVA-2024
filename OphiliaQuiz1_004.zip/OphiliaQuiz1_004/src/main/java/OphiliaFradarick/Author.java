package OphiliaFradarick;

import java.util.Scanner;

//This is an Author class
public class Author {

	
	public static String author_name;
	public static String author_dob;
	
	
	
	//Constructor
	public Author() {
		
	}
	
	
	public String author() {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Authors's name: ");
		String name = input.nextLine();
		
		return name;
	}
	
	public String author_dob() {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Authors's dob: ");
		String name = input.nextLine();
		
		return name;
	}
	
	public void author_information(String name, String dob) {
		System.out.println("The author "+ name+ " was born in "+ dob);
	}
	
	
}
